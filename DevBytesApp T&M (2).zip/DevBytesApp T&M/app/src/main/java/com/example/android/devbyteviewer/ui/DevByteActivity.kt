

package com.example.android.devbyteviewer.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.android.devbyteviewer.R


class DevByteActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dev_byte_viewer)
    }
}
